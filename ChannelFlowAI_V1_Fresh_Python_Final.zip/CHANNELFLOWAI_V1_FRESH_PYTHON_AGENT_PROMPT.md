# ChannelFlowAI V1 — Fresh Python Build / Final Testing Agent Prompt

You are the autonomous engineering agent responsible for building ChannelFlowAI V1.

## PRIMARY OBJECTIVE

I do NOT want a prototype.

I do NOT want a migration.

I do NOT want a Node.js-to-Python conversion project.

I want a FRESH, NATIVE PYTHON PROJECT that reaches:

**FINAL V1 → REAL → WORKING → TESTED → DEPLOYABLE**

The repository must look and behave as if it was created from day one as a Python project.

There must be NO visible legacy Node.js/Bun/TypeScript architecture.

## SOURCE OF TRUTH

Read these files completely:

- ChannelFlowAI_V1_PRD_PYTHON.md
- ChannelFlowAI_V1_UI_UX_PYTHON.md
- ChannelFlowAI_V1_TRD_PYTHON.md

They contain the complete V1 requirements.

Do not remove V1 features while simplifying the implementation.

## COMPLETE V1 FEATURE SET

The final implementation must include all applicable requirements from the documents, including:

- /start
- English + Hinglish
- persistent language
- Back / Cancel / Home
- Telegram account connection
- real OTP authentication
- optional 2FA
- connected status
- reconnect
- disconnect
- session-expiry handling
- one source → one destination per task
- multiple tasks per user
- Active / Paused / Attention Required / Error
- Forward mode
- Copy mode
- Text
- Photo
- Video
- Document
- Audio
- Voice
- message-type filters
- include keywords
- exclude keywords
- case-insensitive matching
- multiple keywords
- Add Header
- Add Footer
- Find & Replace
- Remove Specific Text
- immediate delay
- configurable delay
- queue
- retry
- rate-limit handling
- FloodWait handling
- idempotency
- duplicate protection
- failed-job handling
- list tasks
- view task
- edit task
- pause
- resume
- duplicate
- delete
- statistics
- important system/task notifications
- How it works
- Troubleshooting
- Language settings
- Notification settings
- Account settings
- Test Message before activation
- correct empty/loading/error states
- worker restart recovery
- secure session handling
- multi-user isolation

Do NOT accidentally omit any of these while rebuilding.

## FULL IMPLEMENTATION FREEDOM

You have permission to:

- create
- delete
- rename
- move
- rewrite
- refactor
- simplify
- replace
- reorganize

any repository file necessary.

You do NOT need to preserve existing code.

If the repository contains old/broken code, remove it.

If rebuilding from an empty repository is cleaner, do that.

Do not ask permission for normal engineering decisions.

## IMPORTANT: NO LEGACY PROJECT FEEL

The final repository must NOT contain evidence that it was previously a Node.js/Bun/TypeScript project.

Remove obsolete:

- .ts files
- package.json
- Bun files
- npm/pnpm/yarn lockfiles
- Prisma files
- TypeScript configuration
- BullMQ configuration
- Node-specific scripts
- Node-specific README sections
- migration language that describes a Node.js conversion

The final project should be a clean Python codebase.

## PYTHON STACK

Use:

- Python 3.12+
- aiogram 3.x
- Telethon
- PostgreSQL
- SQLAlchemy 2.x
- Alembic
- asyncpg
- Redis
- arq or a similarly reliable Redis-backed Python queue
- Pydantic Settings
- Docker Compose
- pytest
- pytest-asyncio
- Ruff

Use pinned compatible versions.

Do not introduce another runtime unless there is a compelling technical reason.

## REAL CODE ONLY

Never fake functionality.

NEVER implement:

- fake OTP
- hardcoded OTP
- fake session
- fake forwarding
- fake copy
- fake queue
- fake worker
- fake database
- JSON database pretending to be PostgreSQL
- sleep() pretending to be processing
- print() pretending to be delivery
- placeholder methods returning success
- simulated Telegram API
- random IDs pretending to be Telegram sessions
- TODOs presented as completed features

If a feature is required, implement the real feature.

If it cannot be tested because real external Telegram credentials are unavailable, clearly identify that external testing requirement.

Never fake a successful test.

## DO NOT OVER-ENGINEER

This is extremely important.

Do not write 50 lines where 10 correct lines are enough.

Do not create abstractions simply because they sound professional.

Avoid unnecessary:

- factories
- interfaces
- base classes
- service layers
- repositories
- managers
- utilities
- wrappers
- adapters

Use abstractions only when they provide a real benefit such as isolation, testing, security, or future provider support.

The goal is:

**minimum necessary complexity + maximum correctness.**

Simple code is preferred.

But never sacrifice:

- correctness
- security
- reliability
- testability
- maintainability

just to reduce line count.

## DO NOT PREDICT APIs

Never assume a library API exists.

Verify actual behavior using:

- installed package
- official documentation
- package source when needed
- small controlled tests

Especially verify Telethon and aiogram APIs before building around them.

Do not write speculative code.

## REAL TELETHON AUTHENTICATION

Implement real:

Phone
→ OTP
→ optional 2FA
→ authenticated session

Handle:

- invalid phone
- invalid code
- expired code
- 2FA required
- wrong 2FA password
- cancellation
- FloodWait
- authorization failure
- network failure
- session expiration

Store the authenticated session securely and encrypted at rest.

Never store:

- OTP
- 2FA password
- raw session strings in logs

## REAL TELEGRAM DELIVERY

Implement actual Telegram delivery using the authorized Telethon account.

Forward:

- text
- photo
- video
- document
- audio
- voice

Copy:

- text
- photo
- video
- document
- audio
- voice

Preserve captions where supported.

Respect Telegram permissions and restrictions.

Never claim a delivery succeeded unless Telegram actually accepted it.

## REAL SOURCE MONITORING

Use Telethon events / appropriate Telegram client mechanisms to detect source messages.

For each incoming message:

1. identify applicable active tasks
2. validate account/task access
3. apply message-type filters
4. apply include/exclude keyword filters
5. calculate deterministic fingerprint
6. atomically protect against duplicate delivery
7. apply transformations
8. enqueue job
9. apply delay/rate limiting
10. deliver
11. persist result
12. issue important notification only when appropriate

## REAL DATABASE

PostgreSQL must be authoritative.

Use:

- SQLAlchemy
- asyncpg
- Alembic

Persist all required domain state.

Use:

- foreign keys
- indexes
- unique constraints
- transactions

Never use JSON files as production persistence.

## REAL REDIS QUEUE

Use Redis for background jobs.

Worker must actually process queued jobs.

Implement:

- enqueue
- retry
- backoff
- failure handling
- FloodWait delay
- restart recovery
- task pause/delete checks

## DUPLICATE PROTECTION

Must be atomic.

Use a database unique constraint and transaction strategy based on:

task + source chat + source message

or an equivalent deterministic fingerprint.

Do not rely on:

check → then insert

without race protection.

Concurrent workers must not deliver the same source message twice.

## MULTI-USER ISOLATION

Every account/task operation must be scoped to the correct application user.

User A must never access:

- User B's account
- User B's session
- User B's tasks
- User B's statistics
- User B's delivery records

Test this explicitly.

## BOT UX

Follow the approved UI/UX exactly in behavior and hierarchy.

Start:

/start
→ Language
→ Main Menu

Not connected menu:

- Connect Account
- Features
- Why connect?
- How it works
- Support

Connected menu:

- Create Task
- My Tasks
- Statistics
- Account
- Features
- How it works
- Settings
- Support

Task wizard:

Source
→ Destination
→ Mode
→ Filters
→ Transform
→ Delay
→ Review
→ Test
→ Activate

Implement real Back / Cancel / Home behavior.

## STATE MANAGEMENT

Use aiogram FSM or an equivalent correct state system.

Never use global mutable variables for user state.

Multiple users must be able to use the bot concurrently.

## SECURITY

All secrets must come from environment/secrets management.

At minimum:

- BOT_TOKEN
- TELEGRAM_API_ID
- TELEGRAM_API_HASH
- DATABASE_URL
- REDIS_URL
- ENCRYPTION_KEY

Never commit actual secrets.

Search the repository for accidentally exposed secrets.

If a real credential is discovered, remove it from the codebase and tell the user it must be rotated/revoked.

## TESTING

Do not stop when code merely imports.

Run actual tests.

At minimum:

- unit tests
- integration tests
- database tests
- queue tests
- authentication boundary tests
- delivery tests
- duplicate protection tests
- retry tests
- state transition tests
- access-control tests

If Telegram credentials are available, run controlled E2E tests.

Verify:

1. /start
2. language
3. account connection
4. OTP
5. 2FA
6. session persistence
7. source resolution
8. destination resolution
9. task creation
10. activation
11. text delivery
12. photo
13. video
14. document
15. audio
16. voice
17. Forward mode
18. Copy mode
19. include filter
20. exclude filter
21. message-type filter
22. transformations
23. delay
24. duplicate protection
25. retry
26. FloodWait handling
27. pause
28. resume
29. delete
30. worker restart
31. session recovery
32. destination failure
33. multi-user isolation

When a test fails:

FIX THE IMPLEMENTATION.

Do not modify the test merely to make it pass.

## DOCKER

Provide a clean Docker Compose setup with:

- bot
- worker
- PostgreSQL
- Redis

The system should be straightforward to start.

## README

Write documentation for the final Python project only.

README must explain:

- product
- V1 features
- architecture
- prerequisites
- Telegram API credentials
- environment variables
- local setup
- Docker setup
- migrations
- bot startup
- worker startup
- tests
- known real limitations

Do not mention a previous Node.js implementation.

## DEFINITION OF DONE

Do NOT declare V1 complete until:

- the project is a native Python project
- no legacy runtime files remain
- application starts
- database works
- migrations work
- Redis works
- bot works
- worker works
- onboarding works
- real Telegram authentication works
- secure sessions work
- task creation works
- task management works
- source/destination resolution works
- Forward works
- Copy works
- all required media types work
- filters work
- transformations work
- delay works
- duplicate protection works
- retry works
- FloodWait is handled
- pause/resume/delete work
- statistics work
- required notifications work
- multi-user isolation works
- restart recovery works
- tests pass
- no fake implementations remain
- no hardcoded secrets remain
- README matches reality

## FINAL REPORT

At completion, provide only factual information:

### Implemented
What actually works.

### Tests Run
Exact tests/commands and results.

### Telegram E2E
Exactly what was verified against real controlled Telegram accounts/chats.

### Infrastructure
PostgreSQL / Redis / Docker status.

### Security
Session and secret handling status.

### Known Limitations
Only genuine remaining limitations.

### Run Commands
Exact commands to run the final V1.

Never exaggerate.

Never say "working" if it was not actually tested.

FINAL OBJECTIVE:

**START FRESH.  
BUILD REAL PYTHON.  
IMPLEMENT ALL V1 FEATURES.  
TEST EVERYTHING POSSIBLE.  
FIX FAILURES.  
DELIVER FINAL WORKING V1.**
