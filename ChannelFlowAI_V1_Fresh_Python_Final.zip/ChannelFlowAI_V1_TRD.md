# ChannelFlowAI V1 — Technical Requirements Document

**Version:** 1.1
**Architecture:** Python Telegram automation with bot control plane + authorized Telegram session data plane
**Runtime:** Python 3.12+

## 1. Technical Objective

Build a resilient Telegram-to-Telegram forwarding service with a bot-based control plane and an authorized Telegram user-session data plane.

This is a fresh Python implementation. There is no legacy runtime or architecture to preserve.

## 2. Recommended Python Stack

- Python 3.12+
- aiogram 3.x — Telegram Bot API / bot interaction
- Telethon — MTProto client for authorized user-session operations
- PostgreSQL
- SQLAlchemy 2.x
- Alembic
- asyncpg
- Redis
- arq or equivalent Redis-backed Python job queue
- Pydantic Settings
- Docker / Docker Compose
- Sentry or equivalent error tracking
- pytest + pytest-asyncio
- Ruff

Pin compatible versions in project configuration.

## 3. High-Level Architecture

`Telegram User → aiogram Bot → Application/Orchestrator → PostgreSQL/Redis → Forwarding Workers → Authorized Telethon Session → Source → Destination`

The bot handles control-plane interactions. Workers handle message processing and delivery.

## 4. Domain Model

### User
- id
- telegram_user_id
- username
- language
- status
- timestamps

### TelegramAccount
- id
- user_id
- encrypted session reference
- account identity
- status
- timestamps

### ForwardingTask
- id
- user_id
- source reference
- destination reference
- mode
- delay
- status
- timestamps

### TaskFilter
- task_id
- type
- configuration
- enabled

### TaskTransform
- task_id
- type
- configuration
- priority

### DeliveryRecord
- task_id
- source_chat_id
- source_message_id
- destination_chat_id
- destination_message_id
- fingerprint
- status
- error
- timestamps

Use foreign keys, indexes and unique constraints for multi-user isolation and idempotency.

## 5. Security Requirements

- Never store OTP codes or Telegram passwords as plaintext.
- Encrypt Telegram session material at rest.
- Keep encryption keys outside the database and source control.
- Use least-privilege infrastructure credentials.
- Never log authentication secrets or session strings.
- Validate and sanitize chat identifiers and transformation inputs.
- Disconnect must remove/revoke stored session material from the application side.
- Scope every account/task query to the authenticated application user.
- Never expose another user's task/account/session through callback data or API parameters.
- Never hard-code secrets.

## 6. Task Processing Pipeline

`Receive event → resolve matching tasks → validate task/account → message-type filter → keyword filters → idempotency fingerprint → transformations → enqueue → delay/rate limit → deliver → persist result → important notification`

Use Telethon message events for source monitoring.

## 7. Reliability

- Idempotency keys/fingerprints prevent duplicate delivery.
- Persist job state so worker restarts do not silently lose work.
- Bounded retries with exponential backoff.
- Handle Telegram flood-wait/rate-limit responses by delaying jobs.
- Use failed-job/dead-letter handling for permanent failures.
- Gracefully recover workers after crashes.
- PostgreSQL is authoritative for task state.
- Make duplicate protection atomic with database uniqueness/transactions.
- Paused/deleted tasks must not process new messages.

## 8. Media Requirements

V1 supports:
- text
- photo
- video
- document
- audio
- voice

Preserve captions where supported.

Album/media-group support is deferred unless testing demonstrates it can be safely included without destabilizing the core pipeline.

## 9. State Machines

### Account

`DISCONNECTED → AUTHENTICATING → CONNECTED → EXPIRED/ERROR → RECONNECTING`

### Task

`DRAFT → ACTIVE ↔ PAUSED`

`ACTIVE → ATTENTION_REQUIRED / ERROR`

Deleted tasks must no longer participate in active processing.

## 10. Internal Actions

- `start_user(user_telegram_id)`
- `set_language(user_id, language)`
- `begin_account_auth(user_id)`
- `submit_phone(user_id, phone)`
- `submit_otp(user_id, code)`
- `submit_two_factor(user_id, password)`
- `disconnect_account(user_id)`
- `create_task(user_id, task_config)`
- `test_task(user_id, task_id)`
- `pause_task(user_id, task_id)`
- `resume_task(user_id, task_id)`
- `edit_task(user_id, task_id, patch)`
- `delete_task(user_id, task_id)`
- `get_tasks(user_id)`
- `get_task_stats(user_id)`

## 11. Observability

Track structured events for:

- Authentication
- Task creation
- Queueing
- Delivery success/failure
- Retries
- Rate limits
- Worker health

Never include OTPs, passwords or raw session credentials in logs.

## 12. Performance Targets

- Normal text forwarding should enter the delivery queue quickly after source receipt.
- Workers may process jobs concurrently while respecting Telegram limits.
- Active-task lookup must use indexed database queries.
- Worker restarts must not require users to recreate tasks.
- A slow/failing task must not block unrelated users/tasks.

## 13. Testing

### Unit
- Filters
- Transformations
- Fingerprints
- State transitions
- Access-control checks

### Integration
- Database
- Queue
- Telegram adapter boundaries

### Authentication
- Valid OTP
- Invalid OTP
- Expired OTP
- 2FA
- Cancellation
- Session persistence/reconnect

### Delivery
- Text
- Each supported media type
- Forward mode
- Copy mode

### Reliability
- Retry
- Rate limit / FloodWait
- Duplicate event
- Worker restart
- Destination failure
- Pause/resume/delete
- Concurrent duplicate processing

### End-to-End
Use controlled Telegram accounts and chats.

## 14. Deployment

Start with a small Dockerized deployment:

- Bot/API service
- Worker service
- PostgreSQL
- Redis

Use environment variables/secrets management, automated database backups, health checks and restart policies.

Kubernetes is not required for V1.

## 15. Fresh Python Project Rules

The repository must look like a native Python project.

Do not retain:
- Node.js files
- TypeScript files
- Bun configuration
- npm/pnpm/yarn lockfiles
- Prisma schema/configuration
- BullMQ configuration
- JavaScript package metadata
- legacy Node-specific documentation
- references implying this is a migration from another runtime

Use normal Python project conventions such as:
- pyproject.toml
- requirements.txt if useful
- .env.example
- Dockerfile
- docker-compose.yml
- app/
- tests/
- migrations/

## 16. Future-Proofing

Keep Telegram-specific adapters behind interfaces so future Instagram, WhatsApp, Threads or other providers can be added later.

V1 must not implement those providers or expose them in the UI.
